import src.HomeFrame;
import src.LoginFrame;
import src.game.GameFrame;
import src.game.GamePanel;

import java.io.IOException;

public class App
{
    public static void main(String[] args) throws IOException
    {
        login();
    }

    private static void login() throws IOException
    {
        LoginFrame loginFrame=new LoginFrame();
        loginFrame.setVisible(true);
    }

    /*
    * 主页
    * */
    private static void home() throws IOException
    {
        HomeFrame home=new HomeFrame();
        home.setVisible(true);
    }

    /*
    * 进入2048的游戏页面
    * */
    private static void start2048() throws IOException, ClassNotFoundException
    {
        GameFrame gameFrame = new GameFrame();
        GamePanel gamePanel=new GamePanel(gameFrame);
        gameFrame.add(gamePanel);
        gameFrame.setVisible(true);
    }




}
