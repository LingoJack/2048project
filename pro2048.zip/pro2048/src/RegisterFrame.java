package src;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.HashMap;
import java.util.Map;

public class RegisterFrame extends JFrame implements ActionListener
{
    private JButton commitButton;
    private JButton returnButton;
    private JTextField usernameTextField;
    private JTextField passwordTextField;
    private JTextField repeatPasswordTextField;

    public RegisterFrame() {
        setTitle("Sign up");
        setSize(450, 330);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        getContentPane().add(panel);
        placeComponents(panel);
        setVisible(true);
        setResizable(false);
    }

    private void placeComponents(JPanel panel)
    {
        panel.setLayout(null);

        JLabel titleLabel = new JLabel("Sign up");
        titleLabel.setBounds(164, 20, 105, 40);
        titleLabel.setFont(new Font("Comic Sans MS", Font.BOLD, 20));
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER); // 设置水平对齐方式为居中
        panel.add(titleLabel);

        JLabel usernameLabel = new JLabel("username");
        usernameLabel.setBounds(60, 70, 70, 30);
        panel.add(usernameLabel);

        usernameTextField = new JTextField();
        usernameTextField.setBounds(160, 70, 230, 30);
        panel.add(usernameTextField);

        JLabel passwordLabel = new JLabel("password");
        passwordLabel.setBounds(60, 115, 70, 30);
        panel.add(passwordLabel);

        passwordTextField = new JTextField();
        passwordTextField.setBounds(160, 115, 230, 30);
        panel.add(passwordTextField);

        JLabel repeatPasswordLabel = new JLabel("repeat");
        repeatPasswordLabel.setBounds(60, 165, 70, 30);
        panel.add(repeatPasswordLabel);

        repeatPasswordTextField = new JTextField();
        repeatPasswordTextField.setBounds(160, 165, 230, 30);
        panel.add(repeatPasswordTextField);

        commitButton = new JButton("Commit");
        commitButton.setBounds(90, 210, 110, 40);
        commitButton.addActionListener(this);
        panel.add(commitButton);

        returnButton = new JButton("Back");
        returnButton.setBounds(270, 210, 110, 40);
        returnButton.addActionListener(this);
        panel.add(returnButton);

        commitButton.setActionCommand("register");
        returnButton.setActionCommand("back");
    }

    @Override
    public void actionPerformed(ActionEvent e)
    {
        String command = e.getActionCommand();
        if (command.equals("register"))
        {
            String username = usernameTextField.getText();
            String password = passwordTextField.getText();
            String repeatPassword = repeatPasswordTextField.getText();
            if (isValidRegister(username,password,repeatPassword))
            {
                JOptionPane.showMessageDialog(this, "Sign up successfully.", "", JOptionPane.INFORMATION_MESSAGE);
                try
                {
                    LoginFrame loginFrame = new LoginFrame();
                }
                catch (IOException ex)
                {
                    throw new RuntimeException(ex);
                }
                dispose();
            }
        }
        else if (command.equals("back"))
        {
            try
            {
                LoginFrame loginFrame = new LoginFrame();
            }
            catch (IOException ex)
            {
                throw new RuntimeException(ex);
            }
            dispose();
        }
    }

    private boolean isValidRegister(String username, String password,String repeatPassword)
    {
        if (password.equals(repeatPassword))
        {
            Map<String, String> users = readUsersFromFile();
            if (!users.containsKey(username)) {
                // 执行注册逻辑
                users.put(username, password);
                writeUsersToFile(users); // 更新用户文件
                return true; // 返回注册成功
            } else {
                JOptionPane.showMessageDialog(this, "Username already exists.", "Error", JOptionPane.ERROR_MESSAGE);
                return false; // 返回用户名已存在
            }
        }
        else
        {
            JOptionPane.showMessageDialog(this, "Passwords do not match.", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }

    private void writeUsersToFile(Map<String, String> users)
    {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("src/config/user.txt"))) {
            for (Map.Entry<String, String> entry : users.entrySet()) {
                writer.write(entry.getKey() + " " + entry.getValue());
                writer.newLine(); // 写入一个新行
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private Map<String, String> readUsersFromFile()
    {
        Map<String, String> users = new HashMap<>();
        try (BufferedReader br = new BufferedReader(new FileReader("src/config/user.txt")))
        {
            String line;
            while ((line = br.readLine()) != null)
            {
                String[] parts = line.split(" ");
                if (parts.length == 2)
                {
                    users.put(parts[0], parts[1]);
                }
            }
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
        return users;
    }


}
