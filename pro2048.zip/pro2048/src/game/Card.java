package src.game;

import src.utils.Config;

import java.awt.*;
import java.io.*;

public class Card implements Serializable
{
    // 坐标
    private int x;
    private int y;

    //宽高
    private int width;
    private int height;

    // 下标
    private int i;
    private int j;

    //偏移量
    private int offset;

    //数字
    private int val = 0;

    //是否已经合并过
    private boolean hasMerged = false;

    private int blockNum;

    public Card(int i, int j) throws IOException
    {
        this.width = Integer.parseInt(Config.read("block", "width"));
        this.height = Integer.parseInt(Config.read("block", "height"));
        this.offset = Integer.parseInt(Config.read("block", "gap"));
        this.blockNum = Integer.parseInt(Config.read("block", "num"));

        this.i = i;
        this.j = j;

        // 计算坐标以及各项参数
        calculate();
    }

    /*
     * 绘制卡片
     * */
    public void draw(Graphics g)
    {
        // 获取合适的颜色
        Color color = getColor();
        // 获取之前的画笔颜色
        Color oldColor = g.getColor();
        g.setColor(color);
        g.fillRoundRect(x, y, width, height, 4, 4);

        //绘制数字
        if (val != 0)
        {
            g.setColor(new Color(125, 78, 51));
            Font font = new Font("Comic Sans MS", Font.BOLD, 30);
            g.setFont(font);
            String text = val + "";
            int textLen = getWordWidth(font, text, g);
            int nx = x + (width - textLen) / 2;
            int ny = y + (2 * height) / 3;
            g.drawString(text, nx, ny);
        }

        // 还原画笔的颜色
        g.setColor(oldColor);
    }

    /*
     * 计算卡片的坐标，以及各项参数
     * */
    private void calculate()
    {
        this.x = offset + width * j + (j + 1) * offset;
        this.y = offset + height * i + (i + 1) * offset;
    }

    /*
     * 根据值获取颜色
     * */
    private Color getColor()
    {
        Color color = null;
        switch(val)
        {
            case 2:
                color = new Color(238, 244, 234);
                break;
            case 4:
                color = new Color(218, 112, 214);
                break;
            case 8:
                color = new Color(173, 216, 230);
                break;
            case 16:
                color = new Color(144, 238, 144);
                break;
            case 32:
                color = new Color(255, 255, 224);
                break;
            case 64:
                color = new Color(255, 165, 0);
                break;
            case 128:
                color = new Color(199, 21, 133);
                break;
            case 256:
                color = new Color(148, 0, 211);
                break;
            case 512:
                color = new Color(0, 0, 139);
                break;
            case 1024:
                color = new Color(0, 128, 0);
                break;
            case 2048:
                color = new Color(184, 164, 95);
                break;
            default:
                color = new Color(150, 150, 150);
                break;
        }
        return color;
    }

    /*
     * 获取字体字符串的长度
     * */
    private int getWordWidth(Font font, String content, Graphics g)
    {
        FontMetrics metrics = g.getFontMetrics(font);
        int wid = 0;
        for(int i = 0; i < content.length(); i++)
        {
            wid += metrics.charWidth(content.charAt(i));
        }
        return wid;
    }

    public void setVal(int val)
    {
        this.val = val;
    }

    public int getVal()
    {
        return val;
    }

    public boolean isHasMerged()
    {
        return hasMerged;
    }

    public void setHasMerged(boolean hasMerged)
    {
        this.hasMerged = hasMerged;
    }

    /*
     * 卡片上移
     * */
    public boolean moveTop(Card[][] cards, boolean b)
    {
        // 递归的基准条件
        if (i == 0)
        {
            return false;
        }
        //上一个卡片
        Card upCard = cards[i - 1][j];
        if (upCard.getVal() == 0)
        {
            if (b)
            {
                //空格子，可以移动
                upCard.setVal(this.val);
                this.val = 0;
                upCard.moveTop(cards, b);
            }
            return true;
        }
        else if (upCard.getVal() == val && !upCard.hasMerged)
        {
            if (b)
            {
                //相同数字，合并
                upCard.val *= 2;
                this.val = 0;
                upCard.hasMerged = true;
            }
            return true;
        }
        else
        {
            return false;
        }

    }

    public boolean moveLeft(Card[][] cards, boolean b)
    {
        // 递归的基准条件
        if (j == 0)
        {
            return false;
        }
        //上一个卡片
        Card upCard = cards[i][j - 1];
        if (upCard.getVal() == 0)
        {
            if (b)
            {
                //空格子，可以移动
                upCard.setVal(this.val);
                this.val = 0;
                upCard.moveLeft(cards, b);
            }
            return true;
        }
        else if (upCard.getVal() == val && !upCard.hasMerged)
        {
            if (b)
            {
                //相同数字，合并
                upCard.val *= 2;
                this.val = 0;
                upCard.hasMerged = true;
            }
            return true;
        }
        else
        {
            return false;
        }
    }

    public boolean moveDown(Card[][] cards, boolean b)
    {
        // 递归的基准条件
        if (i == blockNum - 1)
        {
            return false;
        }
        //上一个卡片
        Card upCard = cards[i + 1][j];
        if (upCard.getVal() == 0)
        {
            if (b)
            {
                //空格子，可以移动
                upCard.setVal(this.val);
                this.val = 0;
                upCard.moveDown(cards, b);
            }
            return true;
        }
        else if (upCard.getVal() == val && !upCard.hasMerged)
        {
            if (b)
            {
                //相同数字，合并
                upCard.val *= 2;
                this.val = 0;
                upCard.hasMerged = true;
            }
            return true;
        }
        else
        {
            return false;
        }
    }

    public boolean moveRight(Card[][] cards, boolean b)
    {

        // 递归的基准条件
        if (j == blockNum - 1)
        {
            return false;
        }
        //上一个卡片
        Card upCard = cards[i][j + 1];
        if (upCard.getVal() == 0)
        {
            if (b)
            {
                //空格子，可以移动
                upCard.setVal(this.val);
                this.val = 0;
                upCard.moveRight(cards, b);
            }
            return true;
        }
        else if (upCard.getVal() == val && !upCard.hasMerged)
        {
            if (b)
            {
                //相同数字，合并
                upCard.val *= 2;
                this.val = 0;
                upCard.hasMerged = true;
            }
            return true;
        }
        else
        {
            return false;
        }
    }

    /*
    * 序列化保存
    * */
    public static void saveCards(Card[][] cards, String filename)
    {
        try (ObjectOutputStream outputStream = new ObjectOutputStream(new FileOutputStream(filename)))
        {
            outputStream.writeObject(cards);
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }

    /*
    * 反序列化保存
    * */
    public static Card[][] loadCards(String filename)
    {
        Card[][] cards = null;
        try (ObjectInputStream inputStream = new ObjectInputStream(new FileInputStream(filename)))
        {
            cards = (Card[][]) inputStream.readObject();
        }
        catch (IOException | ClassNotFoundException e)
        {
            e.printStackTrace();
        }
        return cards;
    }
}
