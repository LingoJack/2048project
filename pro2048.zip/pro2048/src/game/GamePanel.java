package src.game;

import src.HomeFrame;
import src.LoginFrame;
import src.RegisterFrame;
import src.utils.Config;
import src.utils.Log;

import javax.swing.*;
import javax.swing.plaf.FontUIResource;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.util.Random;

public class GamePanel extends JPanel implements ActionListener
{
    private JFrame controlFrame;

    private JFrame frame;
    private JPanel panel;

    //行列的格子数
    private int row;
    private int col;
    private Card[][] cards;

    //游戏状态：胜利or进行中
    private String status = "start";

    //计时器
    private JLabel timerLabel; // 计时器组件
    private Timer timer; // 计时器对象
    private int seconds; // 计时器秒数
    JMenuItem ruleMenuItem;

    private int target;
    private String allowProps;
    private String loginStatus;
    private String isLoad;

    private Timer autoSaveTimer;

    private ActionListener timeListener = new ActionListener()
    {
        @Override
        public void actionPerformed(ActionEvent e)
        {
            if (seconds==0)
            {
                gameOver();
                seconds--;
            }
            else if (seconds>0)
            {
                // 更新计时器
                seconds--;
                timerLabel.setText("    Time:" + seconds + "s");
            }
        }
    };

    public GamePanel(JFrame frame) throws IOException, ClassNotFoundException
    {
        this.row = Integer.parseInt(Config.read("block", "num"));
        this.col = Integer.parseInt(Config.read("block", "num"));
        this.target = Integer.parseInt(Config.read("game", "target"));
        this.allowProps =Config.read("game","allow_props");
        this.loginStatus =Config.read("user","status");
        this.isLoad=Config.read("game","isLoad");

        this.setLayout(null);
        this.setOpaque(false); // 设置不透明度
        this.panel = this;
        this.frame = frame;

        // 创建菜单
        createMenu();

        //初始化卡片
        initCard();

        if (isLoad.equals("false"))
        {
            //随机创建一个卡片
            creatRandomNum();
        }

        //创建键盘监听
        createKeyListener();

        //设置自动保存计时器
        initAutoSaveTimer();

        //创建控制器面板
        createController();
    }

    private void createController()
    {
        int gameFrameX = frame.getX();
        int gameFrameY = frame.getY();
        int gameFrameWidth = frame.getWidth();
        int gameFrameHeight = frame.getHeight();

        controlFrame = new JFrame("Controller");
        controlFrame.setVisible(true);
        controlFrame.setSize(300, 300);
        controlFrame.setResizable(false);
        controlFrame.setLocation(gameFrameX + gameFrameWidth, gameFrameY+(gameFrameHeight/4));
        JPanel controlPanel = new JPanel(new GridLayout(3, 3)); // 3x3 网格布局
        controlFrame.add(controlPanel);

        // 创建空白标签，占位用
        JLabel[] emptyLabels = new JLabel[8];
        for (int i = 0; i < 5; i++) {
            emptyLabels[i] = new JLabel("");
            controlPanel.add(emptyLabels[i]);
        }

        JButton upBtn = new JButton("Up");
        JButton leftBtn = new JButton("Left");
        JButton rightBtn = new JButton("Right");
        JButton downBtn = new JButton("Down");

        // 设置按钮的大小
        Dimension buttonSize = new Dimension(100, 100);
        upBtn.setPreferredSize(buttonSize);
        leftBtn.setPreferredSize(buttonSize);
        rightBtn.setPreferredSize(buttonSize);
        downBtn.setPreferredSize(buttonSize);

        // 添加按钮到控制器面板的不同位置
        controlPanel.add(emptyLabels[0]); // 空白标签
        controlPanel.add(upBtn); // 上
        controlPanel.add(emptyLabels[1]); // 空白标签
        controlPanel.add(leftBtn); // 左
        controlPanel.add(emptyLabels[2]); // 空白标签
        controlPanel.add(rightBtn); // 右
        controlPanel.add(emptyLabels[3]); // 空白标签
        controlPanel.add(downBtn); // 下
        controlPanel.add(emptyLabels[4]); // 空白标签

        upBtn.setActionCommand("up");
        leftBtn.setActionCommand("left");
        rightBtn.setActionCommand("right");
        downBtn.setActionCommand("down");

        // 添加按钮点击事件监听器
        upBtn.addActionListener(this);
        leftBtn.addActionListener(this);
        rightBtn.addActionListener(this);
        downBtn.addActionListener(this);

    }

    /*
    * 每隔三秒自动保存游戏进度
    * */
    private void initAutoSaveTimer() {
        autoSaveTimer = new Timer(3000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    autoSave();
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
        });
        autoSaveTimer.start();
    }


    /*
     * 键盘监听事件
     * */
    private void createKeyListener()
    {
        KeyAdapter keyAdapter = new KeyAdapter()
        {
            @Override
            public void keyPressed(KeyEvent e)
            {
                super.keyPressed(e);
                //Log.info("Key is pressed: "+e.getKeyChar());
                int keyCode = e.getKeyCode();
                if (!status.equals("start"))
                {
                    return;
                }
                switch(keyCode)
                {
                    // 上
                    case KeyEvent.VK_UP:
                    case KeyEvent.VK_W:
                        moveCard(1);
                        break;
                    //右
                    case KeyEvent.VK_RIGHT:
                    case KeyEvent.VK_D:
                        moveCard(2);
                        break;
                    //左
                    case KeyEvent.VK_LEFT:
                    case KeyEvent.VK_A:
                        moveCard(4);
                        break;
                    //下
                    case KeyEvent.VK_DOWN:
                    case KeyEvent.VK_S:
                        moveCard(3);
                        break;
                }
            }
        };
        frame.addKeyListener(keyAdapter);
    }

    /*
     * 根据方向键移动卡片
     * */
    private void moveCard(int dir)
    {
        //复原卡片的合并标签
        restoreMergeFlag();
        //dir 上右下左 1234
        if (dir == 1)
        {
            moveCardTop(true);
        }
        else if (dir == 2)
        {
            moveCardRight(true);
        }
        else if (dir == 3)
        {
            moveCardDown(true);
        }
        else if (dir == 4)
        {
            moveCardLeft(true);
        }

        //新创建随机卡片
        creatRandomNum();

        // 重绘
        repaint();

        //判断游戏否结束
        gameOverOrNot();
    }

    /*
     * 判断游戏是否结束
     * */
    private void gameOverOrNot()
    {
        if (isWin())
        {
            gameWin();
        }
        else if (cardsIsFull())
        {
            if (moveCardTop(false) || moveCardDown(false) || moveCardRight(false) || moveCardLeft(false))
            {
                return;
            }
            else
            {
                gameOver();
            }
        }
    }

    private void gameOver()
    {
        Log.info("Fail");
        status = "end";
        UIManager.put("OptionPane.buttonFont", new FontUIResource(new Font("楷体", Font.BOLD, 18)));
        UIManager.put("OptionPane.messageFont", new FontUIResource(new Font("楷体", Font.BOLD, 18)));
        JOptionPane.showMessageDialog(frame, "Fail");
    }

    private void gameWin()
    {
        Log.info("Win");
        status = "end";
        //思源宋体 Comic Sans MS
        UIManager.put("OptionPane.buttonFont", new FontUIResource(new Font("楷体", Font.BOLD, 18)));
        UIManager.put("OptionPane.messageFont", new FontUIResource(new Font("楷体", Font.BOLD, 18)));
        JOptionPane.showMessageDialog(frame, "Win");
    }

    /*
     * 判断是否胜利
     * */
    private boolean isWin()
    {
        Card card;
        for(int i = 0; i < row; i++)
        {
            for(int j = 0; j < col; j++)
            {
                card = cards[i][j];
                if (card.getVal() == target)
                {
                    return true;
                }
            }
        }
        return false;
    }

    /*
     * 复原卡片的合并标签
     * */
    private void restoreMergeFlag()
    {
        for(int i = 0; i < row; i++)
        {
            for(int j = 0; j < col; j++)
            {
                Card card = cards[i][j];
                card.setHasMerged(false);
            }
        }
    }

    private boolean moveCardLeft(boolean b)
    {
        boolean res = false;
        Log.info("move left");
        for(int i = 0; i < row; i++)
        {
            for(int j = 1; j < col; j++)
            {
                Card card = cards[i][j];
                if (card.getVal() != 0)
                {
                    if (card.moveLeft(cards, b))
                    {
                        res = true;
                    }
                }
            }
        }
        return res;
    }

    private boolean moveCardDown(boolean b)
    {
        boolean res = false;
        Log.info("move down");
        for(int i = row - 2; i >= 0; i--)
        {
            for(int j = 0; j < col; j++)
            {
                Card card = cards[i][j];
                if (card.getVal() != 0)
                {
                    if (card.moveDown(cards, b))
                    {
                        res = true;
                    }
                }
            }
        }
        return res;
    }

    private boolean moveCardRight(boolean b)
    {
        boolean res = false;
        Log.info("move right");
        for(int i = 0; i < row; i++)
        {
            for(int j = col - 2; j >= 0; j--)
            {
                Card card = cards[i][j];
                if (card.getVal() != 0)
                {
                    if (card.moveRight(cards, b))
                    {
                        res = true;
                    }
                }
            }
        }
        return res;
    }

    private boolean moveCardTop(boolean b)
    {
        boolean res = false;
        Log.info("move top");
        for(int i = 0; i < row; i++)
        {
            for(int j = 0; j < col; j++)
            {
                Card card = cards[i][j];
                if (card.getVal() != 0)
                {
                    if (card.moveTop(cards, b))
                    {
                        res = true;
                    }
                }
            }
        }
        return res;
    }

    /*
     * 初始化卡片
     * */
    private void initCard() throws IOException, ClassNotFoundException
    {
        if (isLoad.equals("false"))
        {
            cards = new Card[row][col];
            for(int i = 0; i < row; i++)
            {
                for(int j = 0; j < col; j++)
                {
                    Card card = new Card(i, j);
                    cards[i][j] = card;
                }
            }
        }
        else if (isLoad.equals("true"))
        {
            String username = Config.read("user", "current_username");
            String filename = username + "_game.sav";
            SaveInfo saveInfo = SaveInfo.load(filename);
            Card[][] saveInfoCards = saveInfo.getCards();
            this.cards=saveInfoCards;
        }
    }

    @Override
    public void paint(Graphics g)
    {
        super.paint(g);
        //绘制卡片
        drawCard(g);
    }

    /*
     * 绘制卡片
     * */
    private void drawCard(Graphics g)
    {
        for(int i = 0; i < row; i++)
        {
            for(int j = 0; j < col; j++)
            {
                Card card = cards[i][j];
                card.draw(g);
            }
        }
    }

    /*
     * 创建菜单
     * */
    private void createMenu() throws IOException
    {
        //字体
        Font font = createFont();

        //菜单栏
        JMenuBar menuBar = new JMenuBar();

        //菜单项
        JMenu gameMenu = new JMenu(" Game ");
        JMenu userMenu = new JMenu(" User ");
        JMenu helpMenu = new JMenu(" Prop ");
        gameMenu.setFont(font);
        userMenu.setFont(font);
        helpMenu.setFont(font);
        menuBar.add(gameMenu);
        menuBar.add(userMenu);
        menuBar.add(helpMenu);
        frame.setJMenuBar(menuBar);

        if (allowProps.equals("false"))
        {
            helpMenu.setEnabled(false);
        }

        //菜单子项
        JMenuItem newGameMenuItem = new JMenuItem("Restart");
        JMenuItem exitGameMenuItem = new JMenuItem("Exit");
        JMenuItem aboutGameMenuItem = new JMenuItem("Home");
        newGameMenuItem.setFont(font);
        exitGameMenuItem.setFont(font);
        aboutGameMenuItem.setFont(font);
        gameMenu.add(newGameMenuItem);
        gameMenu.add(exitGameMenuItem);
        gameMenu.add(aboutGameMenuItem);

        JMenuItem registerMenuItem = new JMenuItem("Sign up");
        JMenuItem loginMenuItem = new JMenuItem("Log in");
        JMenuItem logoutMenuItem = new JMenuItem("Log out");
        registerMenuItem.setFont(font);
        loginMenuItem.setFont(font);
        logoutMenuItem.setFont(font);
        userMenu.add(registerMenuItem);
        userMenu.add(loginMenuItem);
        userMenu.add(logoutMenuItem);

        JMenuItem SaveMenuItem = new JMenuItem("Save");
        ruleMenuItem = new JMenuItem("Add time");
        SaveMenuItem.setFont(font);
        ruleMenuItem.setFont(font);
        gameMenu.add(SaveMenuItem);
        helpMenu.add(ruleMenuItem);

        //监听事件
        newGameMenuItem.addActionListener(this);
        exitGameMenuItem.addActionListener(this);
        aboutGameMenuItem.addActionListener(this);

        registerMenuItem.addActionListener(this);
        logoutMenuItem.addActionListener(this);
        loginMenuItem.addActionListener(this);

        SaveMenuItem.addActionListener(this);
        ruleMenuItem.addActionListener(this);

        //设置指令
        newGameMenuItem.setActionCommand("restart");
        exitGameMenuItem.setActionCommand("exit");
        aboutGameMenuItem.setActionCommand("home");

        registerMenuItem.setActionCommand("register");
        loginMenuItem.setActionCommand("log in");
        logoutMenuItem.setActionCommand("log out");

        SaveMenuItem.setActionCommand("save");
        ruleMenuItem.setActionCommand("freeze");

        addTimerToMenuBar(frame);
    }

    /*
     * 创建字体
     * */
    private Font createFont()
    {
        return new Font("Comic Sans MS", Font.BOLD, 18);
    }

    /*
     * 监听事件
     * */
    @Override
    public void actionPerformed(ActionEvent e)
    {


        String command = e.getActionCommand();
        Log.info("click button: { " + command + " }");
        if (command.equals("restart"))
        {
            try
            {
                restart();
            }
            catch (IOException ex)
            {
                throw new RuntimeException(ex);
            }
        }
        else if (command.equals("exit"))
        {
            String[] options = {"Yes", "No"};
            int choice = JOptionPane.showOptionDialog(this,
                    "Sure to exit?", "",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.QUESTION_MESSAGE,
                    null,
                    options,
                    options[0]
            );
            if (choice == 0)
            {
                System.exit(0);
            }
        }
        else if (command.equals("home"))
        {
            try
            {
                HomeFrame homeFrame = new HomeFrame();
                homeFrame.setVisible(true);
                frame.dispose();
            }
            catch (IOException ex)
            {
                throw new RuntimeException(ex);
            }

        }
        else if (command.equals("register"))
        {
            RegisterFrame registerFrame = new RegisterFrame();
            registerFrame.setVisible(true);
            frame.dispose();
        }
        else if (command.equals("log in"))
        {
            LoginFrame loginFrame = null;
            try
            {
                loginFrame = new LoginFrame();
            }
            catch (IOException ex)
            {
                throw new RuntimeException(ex);
            }
            loginFrame.setVisible(true);
            frame.dispose();
        }
        else if (command.equals("log out"))
        {
            LoginFrame loginFrame = null;
            try
            {
                loginFrame = new LoginFrame();
            }
            catch (IOException ex)
            {
                throw new RuntimeException(ex);
            }
            try
            {
                Config.modify("user","current_username","");
                Config.modify("user","current_password","");
            }
            catch (IOException ex)
            {
                throw new RuntimeException(ex);
            }
            loginFrame.setVisible(true);
            frame.dispose();
        }
        else if (command.equals("save"))
        {
            if (loginStatus.equals("1"))
            {
                try
                {
                    save();
                }
                catch (IOException ex)
                {
                    throw new RuntimeException(ex);
                }
            }
            else
            {
                //只有登录了才能保存游戏进进度
                JOptionPane.showMessageDialog(frame, "Please log in to save game progress.");
            }
        }
        else if (command.equals("freeze"))
        {
            if (seconds!=-1)
            {
                seconds+=30;
            }
            ruleMenuItem.setEnabled(false);
        }
        else if (command.equals("up"))
        {
            moveCard(1);
        }
        else if (command.equals("right"))
        {
            moveCard(2);
        }
        else if (command.equals("down"))
        {
            moveCard(3);
        }
        else if (command.equals("left"))
        {
            moveCard(4);
        }
    }

    /*
    * 保存游戏进度，每隔三秒会自动保存进度
    * */
    private void save() throws IOException
    {
        //TODO
        /*
        * 需要保存的信息：
        * current_username
        * seconds，不是time
        * status
        * allow_props
        * target
        * block_num
        * cards数组，已经实现了序列化与反序列化，接下来只需要以用户名作为唯一凭证来命名文件即可
        * */
        String username = Config.read("user", "current_username");
        String filename = username + "_game.sav";

        SaveInfo saveInfo=new SaveInfo();
        saveInfo.setSeconds(String.valueOf(seconds));
        saveInfo.setUsername(username);
        saveInfo.setAllowProps(allowProps);
        saveInfo.setBlockNum(String.valueOf(row));
        saveInfo.setTarget(String.valueOf(target));
        saveInfo.setCards(cards);
        saveInfo.setLoginStatus("1");

        SaveInfo.save(saveInfo, filename);

        JOptionPane.showMessageDialog(frame, "Game progress saved successfully.");
    }

    private void autoSave() throws IOException
    {
        String username = Config.read("user", "current_username");
        String filename = username + "_game.sav";

        SaveInfo saveInfo=new SaveInfo();
        saveInfo.setSeconds(String.valueOf(seconds));
        saveInfo.setUsername(username);
        saveInfo.setAllowProps(allowProps);
        saveInfo.setBlockNum(String.valueOf(row));
        saveInfo.setTarget(String.valueOf(target));
        saveInfo.setCards(cards);
        saveInfo.setLoginStatus("1");

        SaveInfo.save(saveInfo, filename);
    }

    /*
     * 新游戏
     * */
    private void restart() throws IOException
    {
        status="start";
        seconds = Integer.parseInt(Config.read("game", "time"));

        // 清空卡片
        for (int i = 0; i < row; i++) {
            for (int j = 0; j < col; j++) {
                cards[i][j].setVal(0);
            }
        }

        creatRandomNum();
        repaint();
    }

    /*
     * 以一定的概率随机生成2或者4的卡片，在随机位置出现
     * */
    private void creatRandomNum()
    {
        //以一定的概率随机生成2或者4
        int num = 0;
        Random random = new Random();
        // 控制出现1-5的随机数，表示2和4随机出现的概率为4/5，1/5
        int ran = random.nextInt(5) + 1;
        if (ran == 1)
        {
            num = 4;
        }
        else
        {
            num = 2;
        }

        //如果已经没有空卡片，直接返回
        if (cardsIsFull())
        {
            return;
        }

        //取到客片
        Card card = getRandomCard(random);
        card.setVal(num);
    }

    /*
     * 判断格子是否全部满了
     * */
    private boolean cardsIsFull()
    {
        for(int i = 0; i < row; i++)
        {
            for(int j = 0; j < col; j++)
            {
                if (cards[i][j].getVal() == 0)
                {
                    return false;
                }
            }
        }
        return true;
    }

    /*
     * 获取随机位置的一张空客片
     * */
    private Card getRandomCard(Random random)
    {
        int xCard = random.nextInt(row);
        int yCard = random.nextInt(col);
        Card card = cards[xCard][yCard];
        int val = card.getVal();
        if (val == 0)
        {
            //说明为空卡片
            return card;
        }
        return getRandomCard(random);
    }

    private void addTimerToMenuBar(JFrame frame) throws IOException
    {
        // 创建计时器组件
        timerLabel = new JLabel("   Time:0s");
        timerLabel.setFont(createFont());

        // 将计时器组件添加到菜单栏
        JMenuBar menuBar = frame.getJMenuBar();
        menuBar.add(timerLabel);

        // 初始化计时器
        String time = Config.read("game", "time");
        seconds = Integer.parseInt(time);

        timer = new Timer(1000, timeListener); // 每隔一秒触发一次 actionPerformed
        timer.start(); // 启动计时器
    }
}
