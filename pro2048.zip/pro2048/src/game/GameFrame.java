package src.game;

import src.utils.Config;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;

public class GameFrame extends JFrame
{
    private int width;
    private int height;

    public GameFrame() throws IOException
    {
        int blockRow=Integer.parseInt(Config.read("block", "num"));
        int blockCol=Integer.parseInt(Config.read("block", "num"));
        int gap=Integer.parseInt(Config.read("block", "gap"));
        int blockHeight=Integer.parseInt(Config.read("block", "height"));
        int blockWidth=Integer.parseInt(Config.read("block", "width"));

        this.width = blockWidth*blockRow+(blockRow+1)*gap+blockWidth/3;
        this.height = blockHeight*blockCol+(blockCol+1)*gap+blockHeight;

        setTitle("2048 Game");
        setSize(width,height);
        getContentPane().setBackground(new Color(66, 133, 211));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);
    }
}
