package src.game;

import java.io.*;

public class SaveInfo implements Serializable
{
    private String username;
    private String seconds;
    private String loginStatus;
    private String allowProps;
    private String target;
    private String blockNum;
    private Card[][] cards;

    public String getUsername()
    {
        return username;
    }

    public void setUsername(String username)
    {
        this.username = username;
    }

    public String getSeconds()
    {
        return seconds;
    }

    public void setSeconds(String seconds)
    {
        this.seconds = seconds;
    }

    public String getLoginStatus()
    {
        return loginStatus;
    }

    public void setLoginStatus(String loginStatus)
    {
        this.loginStatus = loginStatus;
    }

    public String getAllowProps()
    {
        return allowProps;
    }

    public void setAllowProps(String allowProps)
    {
        this.allowProps = allowProps;
    }

    public String getTarget()
    {
        return target;
    }

    public void setTarget(String target)
    {
        this.target = target;
    }

    public String getBlockNum()
    {
        return blockNum;
    }

    public void setBlockNum(String blockNum)
    {
        this.blockNum = blockNum;
    }

    public Card[][] getCards()
    {
        return cards;
    }

    public void setCards(Card[][] cards)
    {
        this.cards = cards;
    }

    public static void save(SaveInfo saveInfo, String filename) throws IOException
    {
        try (ObjectOutputStream outputStream = new ObjectOutputStream(new FileOutputStream(filename)))
        {
            outputStream.writeObject(saveInfo);
        }
    }

    public static SaveInfo load(String filename) throws IOException, ClassNotFoundException {
        try (ObjectInputStream inputStream = new ObjectInputStream(new FileInputStream(filename))) {
            return (SaveInfo) inputStream.readObject();
        }
    }
}
