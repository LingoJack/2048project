package src;

import src.game.GameFrame;
import src.game.GamePanel;
import src.utils.Config;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class LoginFrame extends JFrame implements ActionListener
{

    private JTextField usernameTextField;
    private JTextField passwordTextField;
    private JButton loginButton;
    private JButton registerButton;
    private JButton visitorButton;

    public LoginFrame() throws IOException
    {
        setTitle("Log in");
        setSize(450, 330);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        getContentPane().add(panel);
        placeComponents(panel);
        setVisible(true);
        setResizable(false);
    }

    private void placeComponents(JPanel panel) throws IOException
    {
        panel.setLayout(null);

        JLabel titleLabel = new JLabel("Log in");
        titleLabel.setBounds(164, 20, 105, 40);
        Font font = new Font("Comic Sans MS", Font.BOLD, 20);
        titleLabel.setFont(font);
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER); // 设置水平对齐方式为居中
        panel.add(titleLabel);

        JLabel usernameLabel = new JLabel("username");
        usernameLabel.setBounds(60, 80, 70, 30);
        panel.add(usernameLabel);

        usernameTextField = new JTextField();
        usernameTextField.setBounds(160, 80, 230, 30);
        panel.add(usernameTextField);

        String username = Config.read("user", "current_username");
        usernameTextField.setText(username);

        JLabel passwordLabel = new JLabel("password");
        passwordLabel.setBounds(60, 130, 70, 30);
        panel.add(passwordLabel);

        passwordTextField = new JTextField();
        passwordTextField.setBounds(160, 130, 230, 30);
        panel.add(passwordTextField);

        loginButton = new JButton("Log in");
        loginButton.setBounds(60, 200, 110, 40);
        loginButton.addActionListener(this);
        panel.add(loginButton);

        registerButton = new JButton("Sign up");
        registerButton.setBounds(180, 200, 110, 40);
        registerButton.addActionListener(this);
        panel.add(registerButton);

        visitorButton = new JButton("Guest Login");
        visitorButton.setBounds(300, 200, 110, 40);
        visitorButton.addActionListener(this);
        panel.add(visitorButton);

        loginButton.setActionCommand("log in");
        registerButton.setActionCommand("sign up");
        visitorButton.setActionCommand("guest login");

    }

    @Override
    public void actionPerformed(ActionEvent e)
    {
        String command = e.getActionCommand();
        if (command.equals("log in"))
        {
            String username = usernameTextField.getText();
            String password = passwordTextField.getText();
            if (isValidLogin(username, password))
            {
                try
                {
                    Config.modify("user", "current_username", username);
                    Config.modify("user", "current_password", password);
                    JOptionPane.showMessageDialog(this, "登录成功！", "成功", JOptionPane.INFORMATION_MESSAGE);
                    // 检查是否已经存在游戏窗口，如果不存在则创建
                    try
                    {
                        Config.modify("user", "status", "1");
                        HomeFrame homeFrame = new HomeFrame();
                        homeFrame.setVisible(true);
                    }
                    catch (IOException ex)
                    {
                        throw new RuntimeException(ex);
                    }

                    dispose();
                }
                catch (IOException ex)
                {
                    throw new RuntimeException(ex);
                }
            }
            else
            {
                JOptionPane.showMessageDialog(this, "用户名或密码错误，登录失败！", "错误", JOptionPane.ERROR_MESSAGE);
            }

        }
        else if (command.equals("sign up"))
        {
            RegisterFrame registerFrame = new RegisterFrame();
            registerFrame.setVisible(true);
            dispose();
        }
        else if (command.equals("guest login"))
        {
            try
            {
                Config.modify("user", "status", "2");
            }
            catch (IOException ex)
            {
                throw new RuntimeException(ex);
            }
            HomeFrame homeFrame = null;
            try
            {
                homeFrame = new HomeFrame();
            }
            catch (IOException ex)
            {
                throw new RuntimeException(ex);
            }
            homeFrame.setVisible(true);
            dispose();
        }
    }

    private boolean isValidLogin(String username, String password)
    {
        Map<String, String> users = readUsersFromFile();
        return users.containsKey(username) && users.get(username).equals(password);
    }

    private Map<String, String> readUsersFromFile()
    {
        Map<String, String> users = new HashMap<>();
        try (BufferedReader br = new BufferedReader(new FileReader("src/config/user.txt")))
        {
            String line;
            while ((line = br.readLine()) != null)
            {
                String[] parts = line.split(" ");
                if (parts.length == 2)
                {
                    users.put(parts[0], parts[1]);
                }
            }
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
        return users;
    }
}
