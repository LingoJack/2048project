package src;

import src.game.GameFrame;
import src.game.GamePanel;
import src.game.SaveInfo;
import src.utils.Config;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

public class HomeFrame extends JFrame implements ActionListener
{
    private JButton newGameButton;
    private JButton loadSavedGameButton;
    String[] block_options={"4*4","6*6","8*8","12*12"};
    String[] prop_options={"true","false"};
    String[] time_options={"60s","5min","15min","30min","infinity"};
    String[] target_options={"64","256","1024","2048"};
    JComboBox<String> blockBox = new JComboBox<>(block_options);
    JComboBox<String> propAdmitBox = new JComboBox<>(prop_options);
    JComboBox<String> timeBox = new JComboBox<>(time_options);
    JComboBox<String> targetBox = new JComboBox<>(target_options);

    private GameFrame gameFrame;
    private String username;
    private int loginStatus;

    public HomeFrame() throws IOException
    {
        this.username = Config.read("user", "current_username");
        this.loginStatus = Integer.parseInt(Config.read("user", "status"));

        setTitle("Home");
        setSize(450, 330);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        JPanel panel = new JPanel();
        getContentPane().add(panel);
        placeComponents(panel);
        setVisible(true);
        setResizable(false);
    }

    private void placeComponents(JPanel panel)
    {
        panel.setLayout(null);

        JLabel titleLabel = new JLabel("Home");
        titleLabel.setBounds(164, 5, 105, 40);
        titleLabel.setFont(new Font("Comic Sans MS", Font.BOLD, 20));
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER); // 设置水平对齐方式为居中
        panel.add(titleLabel);

        if (loginStatus==1)
        {
            JLabel userInfoLabel = new JLabel("user: "+username);
            userInfoLabel.setBounds(164, 45, 105, 40);
            userInfoLabel.setFont(new Font("Comic Sans MS", Font.PLAIN, 15));
            userInfoLabel.setHorizontalAlignment(SwingConstants.CENTER); // 设置水平对齐方式为居中
            panel.add(userInfoLabel);
        }
        else if (loginStatus==2)
        {
            JLabel userInfoLabel = new JLabel("user: guest");
            userInfoLabel.setBounds(164, 45, 105, 40);
            userInfoLabel.setFont(new Font("Comic Sans MS", Font.BOLD, 15));
            userInfoLabel.setHorizontalAlignment(SwingConstants.CENTER); // 设置水平对齐方式为居中
            panel.add(userInfoLabel);
        }

        JLabel blockLabel = new JLabel("Block Size:");
        blockLabel.setBounds(100, 100, 80, 25);
        panel.add(blockLabel);

        blockBox.setBounds(190, 100, 100, 25);
        panel.add(blockBox);

        JLabel propAdmitLabel = new JLabel("Allow Props:");
        propAdmitLabel.setBounds(100, 130, 80, 25);
        panel.add(propAdmitLabel);

        propAdmitBox.setBounds(190, 130, 100, 25);
        panel.add(propAdmitBox);

        JLabel timeLabel = new JLabel("Time Limit:");
        timeLabel.setBounds(100, 160, 80, 25);
        panel.add(timeLabel);

        timeBox.setBounds(190, 160, 100, 25);
        panel.add(timeBox);

        JLabel targetLabel = new JLabel("Target Number:");
        targetLabel.setBounds(100, 190, 100, 25);
        panel.add(targetLabel);

        targetBox.setBounds(190, 190, 100, 25);
        panel.add(targetBox);

        newGameButton=new JButton("New Game");
        newGameButton.setBounds(90, 225, 110, 40);
        newGameButton.addActionListener(this);
        panel.add(newGameButton);

        loadSavedGameButton = new JButton("Continue the Saved");
        loadSavedGameButton.setBounds(270, 225, 150, 40);
        loadSavedGameButton.addActionListener(this);
        panel.add(loadSavedGameButton);

        newGameButton.setActionCommand("new");
        loadSavedGameButton.setActionCommand("load");
    }

    @Override
    public void actionPerformed(ActionEvent e)
    {
        String command = e.getActionCommand();
        if (command.equals("new"))
        {
            // 更新模式配置信息
            try
            {
                loadMode();
                if (gameFrame==null)
                {
                    Config.modify("game","isLoad","false");
                    GameFrame gameFrame = new GameFrame();
                    GamePanel gamePanel=new GamePanel(gameFrame);
                    gameFrame.add(gamePanel);
                    gameFrame.setVisible(true);
                }
                else
                {
                    gameFrame.setVisible(true);
                }
                dispose();
            }
            catch (IOException ex)
            {
                throw new RuntimeException(ex);
            }
            catch (ClassNotFoundException ex)
            {
                throw new RuntimeException(ex);
            }
        }
        else if (command.equals("load"))
        {
            if (loginStatus==2)
            {
                JOptionPane.showMessageDialog(this,"Please log in to save game progress.");
            }
            else if (loginStatus==1)
            {
                String username = null;
                try
                {
                    username = Config.read("user", "current_username");
                    String filename = username + "_game.sav";
                    SaveInfo saveInfo = SaveInfo.load(filename);
                    String allowProps = saveInfo.getAllowProps();
                    String blockNum = saveInfo.getBlockNum();
                    String time = saveInfo.getSeconds();
                    String target = saveInfo.getTarget();
                    Config.modify("block","num",blockNum);
                    Config.modify("game","allow_props",allowProps);
                    Config.modify("game","target",target);
                    Config.modify("game","time",time);
                    Config.modify("game","isLoad","true");
                    GameFrame gameFrame = new GameFrame();
                    GamePanel gamePanel=new GamePanel(gameFrame);
                    gameFrame.add(gamePanel);
                    gameFrame.setVisible(true);
                }
                catch (IOException | ClassNotFoundException ex)
                {
                    throw new RuntimeException(ex);
                }


            }
        }
    }

    private void loadMode() throws IOException
    {
        // 获取下拉框的选择
        String selectedBlockSize = (String) blockBox.getSelectedItem();
        String selectedPropAdmit = (String) propAdmitBox.getSelectedItem();
        String selectedTimeLimit = (String) timeBox.getSelectedItem();
        String selectedTargetNumber = (String) targetBox.getSelectedItem();

        //String[] time_options={"60s","5min","15min","30min","infinity"};
        if (selectedTimeLimit.equals("infinity"))
        {
            selectedTimeLimit="-1";
        }
        else if (selectedTimeLimit.equals("60s"))
        {
            selectedTimeLimit="60";
        }
        else if (selectedTimeLimit.equals("5min"))
        {
            selectedTimeLimit=5*60+"";
        }
        else if (selectedTimeLimit.equals("15min"))
        {
            selectedTimeLimit=15*60+"";
        }
        else if (selectedTimeLimit.equals("30min"))
        {
            selectedTimeLimit=30*60+"";
        }

        //{"4*4","6*6","8*8","12*12"}
        if (selectedBlockSize.equals("4*4"))
        {
            selectedBlockSize="4";
        }
        else if (selectedBlockSize.equals("6*6"))
        {
            selectedBlockSize="6";
        }
        else if (selectedBlockSize.equals("8*8"))
        {
            selectedBlockSize="8";
        }
        else if (selectedBlockSize.equals("12*12"))
        {
            selectedBlockSize="12";
        }

        Config.modify("block","num",selectedBlockSize);
        Config.modify("game","allow_props",selectedPropAdmit);
        Config.modify("game","time",selectedTimeLimit);
        Config.modify("game","target",selectedTargetNumber);
    }
}
