package src.utils;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

public class Config
{
    public static String configuration="src/config/configuration.properties";

    /*
    * 读取配置项目
    * */
    public static String read(String section,String option) throws IOException
    {
//        Log.info("Read configuration: { "+section+"."+option+" } from "+ configuration);
        FileInputStream inputStream = new FileInputStream(configuration);
        Properties properties = new Properties();
        properties.load(inputStream);
        inputStream.close();

        String key=section+"."+option;
        String value = properties.getProperty(key);

        return value;
    }

    /*
    * 修改配置项目
    * */
    public static void modify(String section,String option,String value) throws IOException
    {
//        Log.info("Modify configuration: { "+section+"."+option+" },{ "+value+" }");
        FileInputStream inputStream = new FileInputStream(configuration);
        Properties properties = new Properties();
        properties.load(inputStream);
        inputStream.close();

        String key=section+"."+option;
        properties.setProperty(key,value);
        FileOutputStream outputStream = new FileOutputStream(configuration);
        properties.store(outputStream,"configuration has modified successfully~");
        outputStream.close();

    }


}
