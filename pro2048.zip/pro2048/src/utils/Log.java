package src.utils;

public class Log
{
    public static void info(String info)
    {
        System.out.println(info);
    }
}
